OUR UNIVERSE — Vishnupriya website

Open index.html in a browser to preview.
The photos folder contains the uploaded photos used in the gallery.
For the soundtrack, place your legally obtained file named exactly 'Mia & Sebastian's Theme.mp3' beside index.html.
To publish, upload index.html, the photos folder, and the MP3 to Netlify.
